from django.db.models import fields
from rest_framework import serializers
from . import models
from .models import book

class booksSerializers(serializers.ModelSerializer): #it i sfor one cite page 
   
    class Meta:
        model = book
        fields = '__all__' # you can add features instead of __all__


        