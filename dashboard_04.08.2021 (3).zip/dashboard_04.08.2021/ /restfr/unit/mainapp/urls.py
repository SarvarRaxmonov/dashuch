from django.urls import path
from . import views
urlpatterns = [
    path('list-viev', views.bookview.as_view()),
]
