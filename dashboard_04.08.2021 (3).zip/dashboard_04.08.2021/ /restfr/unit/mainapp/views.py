
from django.shortcuts import render
from rest_framework import viewsets, generics
# Create your views here.
from .models import book
from .serializers import booksSerializers
#list amaliyoti , apilar ruyhatini chiqarish get request uchun
class bookview(generics.ListAPIView):
    queryset = book.objects.all() #bu serialazerdan dattaa oladi 
    serializer_class = booksSerializers
    

