from rest_framework import routers
from mainapp import views
router = routers.DefaultRouter()
router.register(r'books', views.bookview)